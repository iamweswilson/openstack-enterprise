var config = {}

config.BB_ACCESS_TOKEN = 'a7cb7f6c03f88535cb12787206d4cce7f4248e138e586275ae97dc7a999dd90d';
config.BB_SITE_ID = 'openstack-homepage.bitballoon.com';
config.BB_SITE_DIR = '_site';


module.exports = config;